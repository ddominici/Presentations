
-- Examine table structure
SELECT TOP 10 *
FROM dbo.ClinicalTrials;


-- 1. Filter on scalar columns (fast, indexable)
SELECT source_id, title, overall_status, enrollment_count
FROM   dbo.ClinicalTrials
WHERE  overall_status = 'RECRUITING';

-- 2. Query NVARCHAR(MAX) JSON string with JSON_VALUE
SELECT source_id,
       JSON_VALUE(full_json_string, '$.metadata.study_type') AS study_type,
       JSON_VALUE(full_json_string, '$.metadata.nct_id')     AS nct_id
FROM   dbo.ClinicalTrials;

-- 3. Shred string JSON array into rows with OPENJSON
SELECT ct.source_id, kw.[value] AS keyword
FROM   dbo.ClinicalTrials ct
CROSS  APPLY OPENJSON(ct.full_json_string, '$.keywords') kw;

-- 4. Query native JSON column (SQL Server 2025) - same JSON_VALUE syntax
SELECT source_id,
       JSON_VALUE(metadata_json, '$.nct_id')         AS nct_id,
       JSON_VALUE(metadata_json, '$.overall_status') AS status
FROM   dbo.ClinicalTrials;

-- 5. Shred native JSON keywords array
SELECT ct.source_id, kw.[value] AS keyword
FROM   dbo.ClinicalTrials ct
CROSS  APPLY OPENJSON(ct.keywords_json) kw;

-- 6. Compare storage sizes
WITH info AS
(
    SELECT source_id,
           DATALENGTH(full_json_string)                    AS nvarchar_bytes,
           DATALENGTH(CAST(metadata_json AS NVARCHAR(MAX))) AS native_json_chars
    FROM   dbo.ClinicalTrials
)
SELECT source_id, 
    nvarchar_bytes, 
    native_json_chars, 
    100.0 - CAST(native_json_chars*100.0/nvarchar_bytes AS DECIMAL(5,2)) as pct_saved
FROM info;

/*
 *  JSON INDEX
 */

-- Demo 1
drop index if exists ixj1 on dbo.ClinicalTrials;
go

create json index ixj1 on dbo.ClinicalTrials(metadata_json)
go

update statistics dbo.ClinicalTrials;
go


-- Demo 2
drop index if exists ixj2 on dbo.ClinicalTrials;
go

create json index ixj2 on dbo.ClinicalTrials(metadata_json) for ('$.official_title', '$.nct_id')
go


update statistics dbo.ClinicalTrials;
go

set statistics io, time on
go


select * from dbo.ClinicalTrials
where json_value(metadata_json, '$.nct_id' returning nvarchar(50)) = N'NCT04982237';
go

-- otherwise better to use json_contains which return *ONLY* the request type (int in this case) 
select * from dbo.ClinicalTrials
where json_contains(metadata_json, 'NCT04982237', '$.nct_id') = 1
go

-- Range filters are also supported by json index
select * from dbo.ClinicalTrials
where json_value(metadata_json, '$.enrollment_count' returning int) between 5 and 15;
go

-- Like
select * from dbo.ClinicalTrials
where json_value(metadata_json, '$.official_title' returning nvarchar(500)) LIKE N'%pneum%';
go

-- Wildcard/pattern-based searches using JSON_CONTAINS
-- Last parameter = 1 means use LIKE instead of =
select * from dbo.ClinicalTrials
where json_contains(metadata_json, N'%intervent%', '$.official_title', 1) = 1;
go 
