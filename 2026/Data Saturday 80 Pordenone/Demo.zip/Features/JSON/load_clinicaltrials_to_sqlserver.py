"""
Load clinical trials JSON data into SQL Server 2025
Demonstrates both NVARCHAR(MAX) string storage and native JSON type (SQL Server 2025+)

Requirements:
    pip install pyodbc
    
Connection: Update SERVER, DATABASE, and auth settings below.
"""

import argparse
import json
import sys

import pyodbc

# ─── Configuration ────────────────────────────────────────────────────────────

SERVER   = "localhost"
DATABASE = "Demo"
# Choose ONE auth method:
# Option A – SQL login
USERNAME = "sa"
PASSWORD = "MyCompl3xPa$$w0rd!"
# Option B – Windows/Azure AD integrated auth (set USE_TRUSTED_CONNECTION=True)
USE_TRUSTED_CONNECTION = False


# --- Input file ---------------------------------------------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Load clinical-trials JSON into SQL Server 2025"
    )
    parser.add_argument(
        "json_file",
        nargs="?",
        default="clinical_trials.json",
        help="Path to the JSON file to load (default: clinical_trials.json)",
    )
    return parser.parse_args()


def load_records(path: str) -> list[dict]:
    """Read JSON from *path*. Accepts a JSON array or a single object."""
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        print(f"ERROR: File not found: {path}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as exc:
        print(f"ERROR: Invalid JSON in {path}: {exc}", file=sys.stderr)
        sys.exit(1)

    if isinstance(data, dict):
        data = [data]
    if not isinstance(data, list):
        print("ERROR: JSON must be an array of records or a single record object.", file=sys.stderr)
        sys.exit(1)

    return data


# --- DDL ----------------------------------------------------------------------

CREATE_TABLE_SQL = """
IF NOT EXISTS (
    SELECT 1 FROM sys.tables WHERE name = 'ClinicalTrials'
)
CREATE TABLE dbo.ClinicalTrials (
    -- Primary key
    id               INT IDENTITY(1,1) PRIMARY KEY,

    -- Scalar columns extracted for indexing and filtering
    source_id        NVARCHAR(50)    NOT NULL,
    source           NVARCHAR(100)   NOT NULL,
    title            NVARCHAR(500)   NOT NULL,
    overall_status   NVARCHAR(50)    NULL,
    study_type       NVARCHAR(50)    NULL,
    enrollment_count INT             NULL,
    start_date       DATE            NULL,
    completion_date  DATE            NULL,
    ingestion_date   DATETIMEOFFSET  NULL,
    url              NVARCHAR(500)   NULL,

    -- Option 1: whole document as NVARCHAR(MAX) string (all SQL Server versions)
    -- Query at runtime with JSON_VALUE / OPENJSON.
    full_json_string NVARCHAR(MAX)   NULL
        CHECK (ISJSON(full_json_string) = 1),

    -- Option 2: native JSON type (SQL Server 2025+)
    -- Stored internally as BSON; no string-parse overhead on read.
    metadata_json    JSON            NULL,
    keywords_json    JSON            NULL,

    loaded_at        DATETIME2       DEFAULT GETDATE()
);
"""

# CAST(? AS JSON) is required: SQL Server will not implicitly cast VARCHAR
# to the native JSON type, so we make the conversion explicit in the SQL.
UPSERT_SQL = """
MERGE dbo.ClinicalTrials AS target
USING (SELECT ? AS source_id) AS source
ON target.source_id = source.source_id
WHEN MATCHED THEN UPDATE SET
    source           = ?,
    title            = ?,
    overall_status   = ?,
    study_type       = ?,
    enrollment_count = ?,
    start_date       = ?,
    completion_date  = ?,
    ingestion_date   = ?,
    url              = ?,
    full_json_string = ?,
    metadata_json    = CAST(? AS JSON),
    keywords_json    = CAST(? AS JSON)
WHEN NOT MATCHED THEN INSERT (
    source_id, source, title, overall_status, study_type,
    enrollment_count, start_date, completion_date, ingestion_date, url,
    full_json_string, metadata_json, keywords_json
) VALUES (
    ?, ?, ?, ?, ?,
    ?, ?, ?, ?, ?,
    ?, CAST(? AS JSON), CAST(? AS JSON)
);
"""

# Total ? placeholders: 1 (USING) + 12 (UPDATE) + 13 (INSERT) = 26
UPSERT_PARAM_COUNT = 26


# --- Helpers ------------------------------------------------------------------

def get_connection() -> pyodbc.Connection:
    if USE_TRUSTED_CONNECTION:
        conn_str = (
            f"DRIVER={{ODBC Driver 18 for SQL Server}};"
            f"SERVER={SERVER};DATABASE={DATABASE};"
            "Trusted_Connection=yes;Encrypt=yes;TrustServerCertificate=yes;"
        )
    else:
        conn_str = (
            f"DRIVER={{ODBC Driver 18 for SQL Server}};"
            f"SERVER={SERVER};DATABASE={DATABASE};"
            f"UID={USERNAME};PWD={PASSWORD};"
            "Encrypt=yes;TrustServerCertificate=yes;"
        )
    return pyodbc.connect(conn_str)


def parse_date(value: str | None) -> str | None:
    """Return ISO date string (YYYY-MM-DD) or None."""
    if not value:
        return None
    return value[:10]


def build_row(record: dict) -> tuple:
    """
    Build the flat parameter tuple for UPSERT_SQL.
    Plain Python str / int / None values only - no Binary wrapping needed
    because cursor.setinputsizes() declares all params as VARCHAR(MAX).
    """
    meta = record.get("metadata") or {}

    source_id        = record.get("source_id")
    source           = record.get("source")
    title            = record.get("title")
    overall_status   = meta.get("overall_status")
    study_type       = meta.get("study_type")
    enrollment_count = meta.get("enrollment_count")
    start_date       = parse_date(meta.get("start_date"))
    completion_date  = parse_date(meta.get("completion_date"))
    ingestion_date   = record.get("ingestion_date")
    url              = record.get("url")
    full_json_string = json.dumps(record, ensure_ascii=False)
    metadata_json    = json.dumps(meta, ensure_ascii=False)
    keywords_json    = json.dumps(record.get("keywords", []), ensure_ascii=False)

    shared = (
        source, title, overall_status, study_type,
        enrollment_count, start_date, completion_date, ingestion_date, url,
        full_json_string, metadata_json, keywords_json,
    )
    # Layout: source_id (USING), UPDATE values x12, source_id (INSERT), INSERT values x12
    return (source_id, *shared, source_id, *shared)


# --- Main ---------------------------------------------------------------------

def main():
    args = parse_args()
    records = load_records(args.json_file)
    print(f"Loaded {len(records)} records from: {args.json_file}")

    print(f"Connecting to {SERVER}/{DATABASE} ...")
    conn = get_connection()
    cursor = conn.cursor()

    print("Creating table if needed ...")
    cursor.execute(CREATE_TABLE_SQL)
    conn.commit()

    # Declare all parameters as VARCHAR(MAX) before executing the upsert.
    # Without this, pyodbc defaults Python str to SQL_WLONGVARCHAR (ntext),
    # which is deprecated and incompatible with SQL Server's native JSON type.
    # size=0 means VARCHAR(MAX); scale=0 is unused for character types.
    cursor.setinputsizes([(pyodbc.SQL_VARCHAR, 0, 0)] * UPSERT_PARAM_COUNT)

    print(f"Loading {len(records)} records ...")
    for i, record in enumerate(records, 1):
        row = build_row(record)
        cursor.execute(UPSERT_SQL, row)
        print(f"  [{i}/{len(records)}] Upserted source_id={record.get('source_id')}")

    conn.commit()
    cursor.close()
    conn.close()

    print("\nDone.")
    print_query_examples()


def print_query_examples():
    print("""
--- Example queries (SSMS / Azure Data Studio) --------------------------------

-- 1. Filter on scalar columns (fast, indexable)
SELECT source_id, title, overall_status, enrollment_count
FROM   dbo.ClinicalTrials
WHERE  overall_status = 'RECRUITING';

-- 2. Query NVARCHAR(MAX) JSON string with JSON_VALUE
SELECT source_id,
       JSON_VALUE(full_json_string, '$.metadata.study_type') AS study_type,
       JSON_VALUE(full_json_string, '$.metadata.nct_id')     AS nct_id
FROM   dbo.ClinicalTrials;

-- 3. Shred string JSON array into rows with OPENJSON
SELECT ct.source_id, kw.[value] AS keyword
FROM   dbo.ClinicalTrials ct
CROSS  APPLY OPENJSON(ct.full_json_string, '$.keywords') kw;

-- 4. Query native JSON column (SQL Server 2025) - same JSON_VALUE syntax
SELECT source_id,
       JSON_VALUE(metadata_json, '$.nct_id')         AS nct_id,
       JSON_VALUE(metadata_json, '$.overall_status') AS status
FROM   dbo.ClinicalTrials;

-- 5. Shred native JSON keywords array
SELECT ct.source_id, kw.[value] AS keyword
FROM   dbo.ClinicalTrials ct
CROSS  APPLY OPENJSON(ct.keywords_json) kw;

-- 6. Compare storage sizes
SELECT source_id,
       DATALENGTH(full_json_string)                    AS nvarchar_bytes,
       DATALENGTH(CAST(metadata_json AS NVARCHAR(MAX))) AS native_json_chars
FROM   dbo.ClinicalTrials;
-------------------------------------------------------------------------------
""")


if __name__ == "__main__":
    main()