USE demo
GO

/*
 * Step 1 - Creazione e popolamento dati di test
 */

DROP TABLE IF EXISTS Customers;
GO

CREATE TABLE Customers (
    id INT IDENTITY(1,1) PRIMARY KEY,
    companyname VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(50),
    country VARCHAR(100),
    address VARCHAR(255),
    postalcode VARCHAR(20),
    region VARCHAR(100),
    city VARCHAR(100)
);

INSERT INTO Customers (companyname, email, phone, country, address, postalcode, region, city) VALUES
-- ITALIA (20 righe)
('Rossi Automazioni', 'info@rossiauto.it', '+39 02 1234567', 'Italy', 'Via Roma 12', '20121', 'Lombardia', 'Milan'),
('Verdi Costruzioni', 'contatti@verdi.it', '+39 06 9876543', 'Italy', 'Viale Europa 45', '00144', 'Lazio', 'Rome'),
('Bianchi Export', 'sales@bianchi.it', '+39 081 5556677', 'Italy', 'Via Toledo 100', '80134', 'Campania', 'Naples'),
('Gallo Software', 'tech@gallosoft.it', '+39 011 2223344', 'Italy', 'Corso Francia 2', '10143', 'Piedmont', 'Turin'),
('Esposito Design', 'hello@esposito.it', '+39 051 445566', 'Italy', 'Via Indipendenza 15', '40121', 'Emilia-Romagna', 'Bologna'),
('Ferrari Meccanica', 'admin@ferrarimecc.it', '+39 059 112233', 'Italy', 'Via Emilia 8', '41121', 'Emilia-Romagna', 'Modena'),
('Marini Logistics', 'logistica@marini.it', '+39 010 998877', 'Italy', 'Via Gramsci 4', '16126', 'Liguria', 'Genoa'),
('Ricci Fashion', 'style@ricci.it', '+39 055 776655', 'Italy', 'Via de Tornabuoni 22', '50123', 'Tuscany', 'Florence'),
('Bruno Food', 'ordini@brunofood.it', '+39 070 334455', 'Italy', 'Via Roma 200', '09124', 'Sardinia', 'Cagliari'),
('Moretti Vini', 'winery@moretti.it', '+39 045 889900', 'Italy', 'Piazza Bra 1', '37121', 'Veneto', 'Verona'),
('Rizzo Consulting', 'hr@rizzo.it', '+39 080 554433', 'Italy', 'Corso Cavour 50', '70121', 'Puglia', 'Bari'),
('Greco Tech', 'support@greco.it', '+39 091 665544', 'Italy', 'Via Libertà 12', '90141', 'Sicily', 'Palermo'),
('Mariani Arredi', 'info@mariani.it', '+39 039 223344', 'Italy', 'Via Monza 5', '20900', 'Lombardia', 'Monza'),
('Conti Energia', 'billing@conti.it', '+39 049 778899', 'Italy', 'Via Prato della Valle 3', '35123', 'Veneto', 'Padua'),
('De Luca Legal', 'studio@deluca.it', '+39 0 Salerno 4455', 'Italy', 'Corso Garibaldi 10', '84123', 'Campania', 'Salerno'),
('Costa Crociere Spa', 'travel@costa.it', '+39 010 112233', 'Italy', 'Piazza Piccapietra 48', '16121', 'Liguria', 'Genoa'),
('Giordano Bio', 'green@giordano.it', '+39 011 667788', 'Italy', 'Via Po 19', '10124', 'Piedmont', 'Turin'),
('Lombardi Finanza', 'broker@lombardi.it', '+39 02 887766', 'Italy', 'Piazza Affari 1', '20123', 'Lombardia', 'Milan'),
('Barbieri Media', 'press@barbieri.it', '+39 051 332211', 'Italy', 'Via Marconi 33', '40122', 'Emilia-Romagna', 'Bologna'),
('Fontana Idrica', 'water@fontana.it', '+39 06 443322', 'Italy', 'Via Appia Nuova 101', '00183', 'Lazio', 'Rome'),

-- USA (20 righe)
('TechNova Inc', 'contact@technova.com', '+1 212 555 0199', 'USA', '123 Broadway', '10001', 'NY', 'New York'),
('Blue Sky Solutions', 'info@bluesky.com', '+1 310 555 0244', 'USA', '456 Sunset Blvd', '90028', 'CA', 'Los Angeles'),
('Golden Gate Goods', 'sales@goldengate.com', '+1 415 555 0355', 'USA', '789 Market St', '94103', 'CA', 'San Francisco'),
('Windy City Corp', 'hello@windycity.com', '+1 312 555 0466', 'USA', '101 Michigan Ave', '60601', 'IL', 'Chicago'),
('Lone Star Logistics', 'trucking@lonestar.com', '+1 512 555 0577', 'USA', '202 Austin Way', '73301', 'TX', 'Austin'),
('Liberty Bell Law', 'legal@libertybell.com', '+1 215 555 0688', 'USA', '303 Chestnut St', '19106', 'PA', 'Philadelphia'),
('Peach State Media', 'ads@peachstate.com', '+1 404 555 0799', 'USA', '404 Peachtree St', '30303', 'GA', 'Atlanta'),
('Emerald City Tech', 'cloud@emeraldcity.com', '+1 206 555 0811', 'USA', '505 Pike St', '98101', 'WA', 'Seattle'),
('Rocky Mountain Mining', 'ore@rockymountain.com', '+1 303 555 0922', 'USA', '606 Mile High Ave', '80202', 'CO', 'Denver'),
('Sunshine State Real Estate', 'homes@sunshine.com', '+1 305 555 1033', 'USA', '707 Ocean Dr', '33139', 'FL', 'Miami'),
('Desert Oasis Resorts', 'stay@desertoasis.com', '+1 602 555 1144', 'USA', '808 Camelback Rd', '85001', 'AZ', 'Phoenix'),
('Motor City Parts', 'auto@motorcity.com', '+1 313 555 1255', 'USA', '909 Woodward Ave', '48226', 'MI', 'Detroit'),
('Steel City Forge', 'metal@steelcity.com', '+1 412 555 1366', 'USA', '111 Smithfield St', '15219', 'PA', 'Pittsburgh'),
('Rose City Flowers', 'blooms@rosecity.com', '+1 503 555 1477', 'USA', '222 Burnside St', '97201', 'OR', 'Portland'),
('Gateway Arch Ent', 'events@gateway.com', '+1 314 555 1588', 'USA', '333 Broadway', '63102', 'MO', 'St. Louis'),
('Crescent City Jazz', 'music@crescentcity.com', '+1 504 555 1699', 'USA', '444 Bourbon St', '70112', 'LA', 'New Orleans'),
('Music City Records', 'tunes@musiccity.com', '+1 615 555 1711', 'USA', '555 Broadway', '37203', 'TN', 'Nashville'),
('Alamo History Co', 'tours@alamo.com', '+1 210 555 1822', 'USA', '666 Houston St', '78205', 'TX', 'San Antonio'),
('Monumental Policy', 'insurance@monumental.com', '+1 202 555 1933', 'USA', '777 Pennsylvania Ave', '20006', 'DC', 'Washington'),
('Harbor Point Logistics', 'shipping@harbor.com', '+1 617 555 2044', 'USA', '888 Atlantic Ave', '02110', 'MA', 'Boston'),

-- UK (20 righe)
('London Bridge Trading', 'sales@londonbridge.uk', '+44 20 7946 0000', 'UK', '10 Downing St', 'SW1A 2AA', 'Greater London', 'London'),
('Manchester Mills', 'info@manchestermills.co.uk', '+44 161 496 0123', 'UK', '22 Canal St', 'M1 3HE', 'Greater Manchester', 'Manchester'),
('Birmingham Steel', 'factory@birminghamsteel.uk', '+44 121 496 0456', 'UK', '45 Bullring', 'B5 4BU', 'West Midlands', 'Birmingham'),
('Edinburgh Arts', 'gallery@edinburgharts.uk', '+44 131 496 0789', 'UK', 'Royal Mile 1', 'EH1 1SG', 'Midlothian', 'Edinburgh'),
('Glasgow Marine', 'ships@glasgowmarine.uk', '+44 141 496 0111', 'UK', 'Clyde St 50', 'G1 4JJ', 'Lanarkshire', 'Glasgow'),
('Liverpool Sounds', 'records@liverpoolsounds.uk', '+44 151 496 0222', 'UK', 'Mathew St 10', 'L2 6RE', 'Merseyside', 'Liverpool'),
('Leeds Logistics', 'transport@leedslog.uk', '+44 113 496 0333', 'UK', 'Briggate 5', 'LS1 6AZ', 'West Yorkshire', 'Leeds'),
('Bristol Aerospace', 'flight@bristolaero.uk', '+44 117 496 0444', 'UK', 'Whiteladies Rd 12', 'BS8 1PD', 'Bristol', 'Bristol'),
('Sheffield Blades', 'cutlery@sheffield.uk', '+44 114 496 0555', 'UK', 'High St 90', 'S1 2GA', 'South Yorkshire', 'Sheffield'),
('Cardiff Coal', 'energy@cardiffcoal.uk', '+44 29 2046 0666', 'UK', 'Queen St 15', 'CF10 2HQ', 'Glamorgan', 'Cardiff'),
('Belfast Linen', 'textiles@belfastlinen.uk', '+44 28 9046 0777', 'UK', 'Donegall Sq 8', 'BT1 5GS', 'Antrim', 'Belfast'),
('Oxford Books', 'library@oxfordbooks.uk', '+44 1865 496088', 'UK', 'High St 101', 'OX1 4BJ', 'Oxfordshire', 'Oxford'),
('Cambridge Tech', 'lab@cambridgetech.uk', '+44 1223 496099', 'UK', 'King’s Parade 12', 'CB2 1ST', 'Cambridgeshire', 'Cambridge'),
('Brighton Pier Ent', 'fun@brightonpier.uk', '+44 1273 496100', 'UK', 'Marine Parade 1', 'BN2 1TW', 'East Sussex', 'Brighton'),
('Newcastle Coal', 'mining@newcastle.uk', '+44 191 496 0111', 'UK', 'Grey St 25', 'NE1 6EE', 'Tyne and Wear', 'Newcastle'),
('Nottingham Lace', 'fabrics@nottingham.uk', '+44 115 496 0222', 'UK', 'Market Sq 4', 'NG1 2AS', 'Nottinghamshire', 'Nottingham'),
('Leicester Textiles', 'wear@leicester.uk', '+44 116 496 0333', 'UK', 'Gallowtree Gate 10', 'LE1 5AD', 'Leicestershire', 'Leicester'),
('Southampton Dock', 'cargo@southampton.uk', '+44 23 8046 0444', 'UK', 'High St 55', 'SO14 2DF', 'Hampshire', 'Southampton'),
('Aberdeen Oil', 'rig@aberdeenoil.uk', '+44 1224 496055', 'UK', 'Union St 200', 'AB10 1TP', 'Aberdeenshire', 'Aberdeen'),
('York History Tours', 'guide@yorktours.uk', '+44 1904 496066', 'UK', 'The Shambles 1', 'YO1 7LZ', 'North Yorkshire', 'York'),

-- GERMANY (20 righe)
('Berlin Tech GmbH', 'kontakt@berlintech.de', '+49 30 1234567', 'Germany', 'Alexanderplatz 1', '10178', 'Berlin', 'Berlin'),
('München Auto AG', 'info@munchenauto.de', '+49 89 9876543', 'Germany', 'Marienplatz 5', '80331', 'Bavaria', 'Munich'),
('Hamburg Hafen LLC', 'cargo@hamburghafen.de', '+49 40 1122334', 'Germany', 'Reeperbahn 10', '20359', 'Hamburg', 'Hamburg'),
('Frankfurt Banken', 'finance@frankfurtbank.de', '+49 69 4455667', 'Germany', 'Zeil 100', '60313', 'Hesse', 'Frankfurt'),
('Köln Messe', 'events@koelnmesse.de', '+49 221 5566778', 'Germany', 'Hohe Str 50', '50667', 'North Rhine-Westphalia', 'Cologne'),
('Stuttgart Engineering', 'engine@stuttgart.de', '+49 711 6677889', 'Germany', 'Königstraße 15', '70173', 'Baden-Württemberg', 'Stuttgart'),
('Düsseldorf Mode', 'fashion@duesseldorf.de', '+49 211 7788990', 'Germany', 'Königsallee 2', '40212', 'North Rhine-Westphalia', 'Dusseldorf'),
('Leipzig Logistik', 'box@leipziglog.de', '+49 341 8899001', 'Germany', 'Grimmaische Str 10', '04109', 'Saxony', 'Leipzig'),
('Dortmund Stahl', 'steel@dortmund.de', '+49 231 9900112', 'Germany', 'Westenhellweg 5', '44137', 'North Rhine-Westphalia', 'Dortmund'),
('Essen Energie', 'power@essen.de', '+49 201 1122334', 'Germany', 'Limbecker Platz 1', '45127', 'North Rhine-Westphalia', 'Essen'),
('Bremen Werft', 'ships@bremen.de', '+49 421 2233445', 'Germany', 'Sögestraße 20', '28195', 'Bremen', 'Bremen'),
('Dresden Optik', 'lens@dresden.de', '+49 351 3344556', 'Germany', 'Prager Str 8', '01069', 'Saxony', 'Dresden'),
('Hannover Messe AG', 'expo@hannover.de', '+49 511 4455667', 'Germany', 'Georgstraße 12', '30159', 'Lower Saxony', 'Hanover'),
('Nürnberg Spielzeug', 'toys@nuernberg.de', '+49 911 5566778', 'Germany', 'Königstraße 30', '90402', 'Bavaria', 'Nuremberg'),
('Duisburg Logistik', 'port@duisburg.de', '+49 203 6677889', 'Germany', 'Königstraße 40', '47051', 'North Rhine-Westphalia', 'Duisburg'),
('Bochum Pharma', 'med@bochum.de', '+49 234 7788990', 'Germany', 'Kortumstraße 10', '44787', 'North Rhine-Westphalia', 'Bochum'),
('Wuppertal Bahn', 'train@wuppertal.de', '+49 202 8899001', 'Germany', 'Werth 5', '42275', 'North Rhine-Westphalia', 'Wuppertal'),
('Bielefeld Web', 'online@bielefeld.de', '+49 521 9900112', 'Germany', 'Bahnhofstraße 15', '33602', 'North Rhine-Westphalia', 'Bielefeld'),
('Bonn Global', 'world@bonn.de', '+49 228 1122334', 'Germany', 'Sternstraße 2', '53111', 'North Rhine-Westphalia', 'Bonn'),
('Münster Uni', 'edu@muenster.de', '+49 251 2233445', 'Germany', 'Prinzipalmarkt 1', '48143', 'North Rhine-Westphalia', 'Munster'),

-- FRANCE (20 righe)
('Paris Luxe', 'contact@parisluxe.fr', '+33 1 42 66 00 00', 'France', 'Rue de Rivoli 1', '75001', 'Île-de-France', 'Paris'),
('Lyon Soie', 'info@lyonsoie.fr', '+33 4 78 39 00 00', 'France', 'Place Bellecour 5', '69002', 'Auvergne-Rhône-Alpes', 'Lyon'),
('Marseille Port', 'shipping@marseille.fr', '+33 4 91 14 00 00', 'France', 'La Canebière 10', '13001', 'Provence-Alpes-Côte d''Azur', 'Marseille'),
('Toulouse Aero', 'air@toulouse.fr', '+33 5 61 22 00 00', 'France', 'Place du Capitole 1', '31000', 'Occitanie', 'Toulouse'),
('Nice Azur', 'beach@nice.fr', '+33 4 93 81 00 00', 'France', 'Promenade des Anglais 50', '06000', 'Provence-Alpes-Côte d''Azur', 'Nice'),
('Nantes Marine', 'ocean@nantes.fr', '+33 2 40 41 00 00', 'France', 'Cours des 50 Otages 12', '44000', 'Pays de la Loire', 'Nantes'),
('Strasbourg Euro', 'admin@strasbourg.fr', '+33 3 88 15 00 00', 'France', 'Place Kleber 2', '67000', 'Grand Est', 'Strasbourg'),
('Montpellier Tech', 'soft@montpellier.fr', '+33 4 67 34 00 00', 'France', 'Place de la Comédie 8', '34000', 'Occitanie', 'Montpellier'),
('Bordeaux Vin', 'wine@bordeaux.fr', '+33 5 56 10 00 00', 'France', 'Cours de l''Intendance 15', '33000', 'Nouvelle-Aquitaine', 'Bordeaux'),
('Lille Nord', 'sales@lille.fr', '+33 3 20 49 00 00', 'France', 'Grand Place 1', '59000', 'Hauts-de-France', 'Lille'),
('Rennes Breton', 'cider@rennes.fr', '+33 2 99 67 00 00', 'France', 'Rue de la Monnaie 4', '35000', 'Brittany', 'Rennes'),
('Reims Champagne', 'bubbly@reims.fr', '+33 3 26 77 00 00', 'France', 'Place Cardinale 10', '51100', 'Grand Est', 'Reims'),
('Le Havre Logistics', 'dock@lehavre.fr', '+33 2 35 19 00 00', 'France', 'Rue de Paris 20', '76600', 'Normandy', 'Le Havre'),
('Saint-Etienne Design', 'style@stetienne.fr', '+33 4 77 48 00 00', 'France', 'Rue de la République 5', '42000', 'Auvergne-Rhône-Alpes', 'Saint-Etienne'),
('Toulon Marine', 'navy@toulon.fr', '+33 4 94 36 00 00', 'France', 'Avenue de la République 100', '83000', 'Provence-Alpes-Côte d''Azur', 'Toulon'),
('Grenoble Alps', 'ski@grenoble.fr', '+33 4 76 76 00 00', 'France', 'Grand Rue 12', '38000', 'Auvergne-Rhône-Alpes', 'Grenoble'),
('Dijon Moutarde', 'food@dijon.fr', '+33 3 80 74 00 00', 'France', 'Rue de la Liberté 3', '21000', 'Bourgogne-Franche-Comté', 'Dijon'),
('Angers Vert', 'garden@angers.fr', '+33 2 41 05 00 00', 'France', 'Rue Plantagenêt 8', '49000', 'Pays de la Loire', 'Angers'),
('Nîmes Denim', 'jeans@nimes.fr', '+33 4 66 76 00 00', 'France', 'Boulevard Victor Hugo 2', '30000', 'Occitanie', 'Nimes'),
('Aix Provence', 'herbs@aix.fr', '+33 4 42 91 00 00', 'France', 'Cours Mirabeau 15', '13100', 'Provence-Alpes-Côte d''Azur', 'Aix-en-Provence');

CREATE NONCLUSTERED INDEX NCIX_Customers_CompanyName ON Customers (CompanyName);
CREATE NONCLUSTERED INDEX NCIX_Customers_Email ON Customers (Email);

UPDATE STATISTICS Customers;

-------------------------------------------------------------------------------

/*
 * Step 2 - Ricerca con RegExp
 */

-- 1. Trovare aziende che iniziano con 'A', 'B' o 'C'
SELECT companyname, city
FROM Customers
WHERE REGEXP_LIKE(companyname, '^[A-C]', 'i');

-- 2. Validazione Email: Trovare email che non hanno un formato standard
-- (Cerca stringhe che NON hanno: testo + @ + testo + . + 2-4 lettere)
SELECT companyname, email
FROM Customers
WHERE NOT REGEXP_LIKE(email, '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$');

--UPDATE Customers SET Email = 'info@rossiautom@zioni.n3t' WHERE companyname = 'Rossi Automazioni'

-- 3. Cercare numeri di telefono che contengono una sequenza specifica
-- Esempio: numeri che hanno tre cifre identiche consecutive (es. 555)
-- Non funziona: SQL Server 2025 non implementa i backreferences
SELECT companyname, phone
FROM Customers
WHERE REGEXP_LIKE(phone, '([0-9])\1\1');

SELECT companyname, phone
FROM Customers
WHERE REGEXP_LIKE(phone, '000|111|222|333|444|555|666|777|888|999');      

-- 4. Trova telefoni USA o UK
SELECT companyname, phone, country
FROM Customers
WHERE REGEXP_LIKE(phone, '^(\+1|\+44)');

-- 5. Filtrare per città che terminano con 'n' o 'o' (Case Insensitive)
SELECT companyname, city, country
FROM Customers
WHERE REGEXP_LIKE(city, '[no]$', 'i');

-- 6. Estrarre aziende che hanno "Tech", "Software" o "Solutions" nel nome
SELECT companyname
FROM Customers
WHERE REGEXP_LIKE(companyname, 'Tech|Software|Solutions', 'i');

/*
 * Step 3 - Aggiungo note testuali contenenti un numero di telefono
 */
ALTER TABLE Customers 
ADD note NVARCHAR(500);

WITH RandomSelection AS (
    -- Selezioniamo il 30% delle righe in modo casuale
    SELECT TOP (30) PERCENT *
    FROM Customers
    ORDER BY NEWID()
)
UPDATE RandomSelection
SET note = 'Contattare il Sig. ' + 
    CASE 
        WHEN country = 'Italy' THEN 'Rossi'
        WHEN country = 'USA' THEN 'Smith'
        WHEN country = 'UK' THEN 'Jones'
        WHEN country = 'Germany' THEN 'Müller'
        ELSE 'Lefebvre'
    END + ' al numero ' + phone;

SELECT 
    companyname,
    note,
    REGEXP_SUBSTR(Note, '\d{3} \d{6}') AS ExtractedPhone
FROM Customers
WHERE REGEXP_LIKE(Note, '\d{3} \d{6}');

/*
 * Step 4 - Aggiungo il codice fiscale
 */

-- Assicuriamoci che la colonna esista
ALTER TABLE Customers ADD tax_code VARCHAR(16);

-- Popolamento con logica strutturata
UPDATE Customers
SET tax_code = CASE 
    WHEN country = 'Italy' THEN 
        -- 3 Lettere Cognome + 3 Lettere Nome
        CHAR(65+(ABS(CHECKSUM(NEWID()))%26)) + CHAR(65+(ABS(CHECKSUM(NEWID()))%26)) + CHAR(65+(ABS(CHECKSUM(NEWID()))%26)) +
        CHAR(65+(ABS(CHECKSUM(NEWID()))%26)) + CHAR(65+(ABS(CHECKSUM(NEWID()))%26)) + CHAR(65+(ABS(CHECKSUM(NEWID()))%26)) +
        -- Anno (es. 85)
        RIGHT('0' + CAST(ABS(CHECKSUM(NEWID()))%99 AS VARCHAR), 2) +
        -- Mese (Lettera casuale tra le 12 valide)
        SUBSTRING('ABCDEHLMPRST', (ABS(CHECKSUM(NEWID()))%12)+1, 1) +
        -- Giorno + Sesso (Uomo 01-31, Donna 41-71)
        RIGHT('0' + CAST(CASE WHEN ABS(CHECKSUM(NEWID()))%2=0 THEN (ABS(CHECKSUM(NEWID()))%31)+1 ELSE (ABS(CHECKSUM(NEWID()))%31)+41 END AS VARCHAR), 2) +
        -- Codice Comune (Es. H501 per Roma, F205 per Milano - simulato con 1 Lettera + 3 Numeri)
        CHAR(65+(ABS(CHECKSUM(NEWID()))%26)) + RIGHT('00' + CAST(ABS(CHECKSUM(NEWID()))%999 AS VARCHAR), 3) +
        -- Carattere di controllo finale
        CHAR(65+(ABS(CHECKSUM(NEWID()))%26))
    ELSE 
        -- Per l'estero manteniamo un numero identificativo (Partita IVA o simile)
        CAST(CAST(ABS(CHECKSUM(NEWID())) AS BIGINT) % 90000000000 + 10000000000 AS VARCHAR(16))
    END;

CREATE NONCLUSTERED INDEX NCIX_Customers_tax_code ON Customers (tax_code)


/*
 * Step 5 - Ricerca sui nuovi campi
 */

SELECT TOP 10 * FROM customers

-- Non fuziona: no backreferences
SELECT 
    companyname, 
    REGEXP_REPLACE(tax_code, '^(.{3}).*(.{3})$', '$1**********$2') AS Masked_tax_code, country
FROM Customers
WHERE country = 'Italy'

-- Se proprio voglio usare REGEXP_REPLACE...
SELECT 
    companyname,
    REGEXP_REPLACE(tax_code, SUBSTRING(tax_code, 4, 10), '**********') AS Masked_tax_code
FROM Customers
WHERE country = 'Italy';



-- In ogni caso posso usare Dynamic Data Masking !
-- Applichiamo una maschera permanente alla colonna
ALTER TABLE Customers  
ALTER COLUMN tax_code ADD MASKED WITH (FUNCTION = 'partial(3, "**********", 3)');

-- Come Admin
SELECT companyname, tax_code FROM Customers;

-- Come altro utente
CREATE USER my_reader FOR LOGIN my_reader;

GRANT SELECT ON Customers TO my_reader;

EXECUTE AS USER = 'my_reader';

SELECT companyname, tax_code FROM Customers;
GO

REVERT;
GO


/*
 * Scenario 3 - Usare le RegExp per validare i dati in ingresso automaticamente
 * (CHECK constraint)
 */

CREATE TABLE Customers2 
(
    id INT IDENTITY(1,1) PRIMARY KEY,
    companyname VARCHAR(255) NOT NULL,
    email VARCHAR(255)
        CHECK (REGEXP_LIKE(Email, '^[A-Za-z0-9%+-]+(?:.[A-Za-z0-9%+-]+)@[A-Za-z0-9-]+(?:.[A-Za-z0-9-]+).[A-Za-z]{2,}$')),  
    phone VARCHAR(50),
    country VARCHAR(100),
    address VARCHAR(255),
    postalcode VARCHAR(20),
    region VARCHAR(100),
    city VARCHAR(100)
);

INSERT INTO Customers2 (companyname, email, phone, country, address, postalcode, region, city) VALUES
('Rossi Automazioni', 'info@rossi@auto.2r', '+39 02 1234567', 'Italy', 'Via Roma 12', '20121', 'Lombardia', 'Milan')




