﻿#
# SQL Saturday 707 Pordenone
# 
# Download all folder content from SSRS to disk
#

Import-Module ReportingServicesTools

Out-RsFolderContent -RsFolder "/SqlSat707" -Recurse -Destination C:\SQLSat707\Downloads -ReportServerUri http://localhost/reportserver

#EOF