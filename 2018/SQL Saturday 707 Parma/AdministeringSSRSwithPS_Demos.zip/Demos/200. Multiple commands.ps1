﻿#
# SQL Saturday 707 Pordenone
# 
# Multiple commands using ReportingServicesTools
#

Import-Module ReportingServicesTools

$parentFolder = "/"
$newFolder    = "SqlSat707_bis";

# Create a new folder on root if not exists
Try {
    Get-RsCatalogItems -RsFolder "/SQLSat707_bis" -ReportServerUri http://localhost/reportserver -ErrorAction SilentlyContinue
} 
Catch {
    Write-Host "Creating folder $($parentFolder)$($newFolder)";
    New-RsFolder -RsFolder $parentFolder -FolderName $newFolder -ReportServerUri http://localhost/reportserver
}

# Secure newly created folder
Grant-RsCatalogItemRole -Identity "DESKTOP-3HOJN25\ReportUser" -RoleName "Publisher" -Path "/SQLSat707_bis" -ReportServerUri http://localhost/reportserver

# Import data source 
# Out-RsCatalogItem -RsItem "/SqlSat707/AdventureWorks2014" -Destination "C:\sqlsat707\downloads" -ReportServerUri  http://localhost/reportserver
Write-RsCatalogItem -RsFolder "/SQLSat707_bis" -Path "C:\SQLSat707\Downloads\AdventureWorks2014.rsds" -Overwrite -ReportServerUri http://localhost/reportserver

# Import report
# Out-RsCatalogItem -RsItem "/SqlSat707/Product List" -Destination "C:\sqlsat707\downloads" -ReportServerUri  http://localhost/reportserver
Write-RsCatalogItem -RsFolder "/SQLSat707_bis" -Path "C:\SQLSat707\Source\Product List.rdl" -Overwrite -ReportServerUri http://localhost/reportserver
