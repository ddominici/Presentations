﻿#
# SQL Saturday 707 Pordenone
# 
# Create folder using the CreateFolder web service method
#
# https://msdn.microsoft.com/en-us/library/reportservice2010.reportingservice2010.createfolder.aspx
#

$folder    = "/Performance Dashboard";

$ssrsServer = "http://localhost/ReportServer";

$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;


$ssrsMgmtProxy.ListChildren($folder,$false) |
    Where-Object { $_.TypeName -eq "Report" } | Out-GridView;

#EOF