﻿#
# SQL Saturday 707 Pordenone
# 
# List folders
#
# https://msdn.microsoft.com/en-us/library/reportservice2010.reportingservice2010.createfolder.aspx
#

$folder     = "/";

$ssrsServer = "http://localhost/ReportServer";

$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;

$ssrsMgmtProxy.ListChildren($folder, $false) |
    Where-Object { $_.TypeName -eq "Folder" } | Out-GridView;

#EOF