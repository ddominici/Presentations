﻿#
# SQL Saturday 707 Pordenone
#
# https://github.com/Microsoft/Reporting-Services/blob/master/APISamples/powershell/powershellSamples.ps1
#

$ReportPortalUri = 'http://localhost/reports'

Write-Host "Upload an item..."
$uploadItemPath = 'C:\SQLSat707\Source\Product List.rdl'
$catalogItemsUri = $ReportPortalUri + "/api/v2.0/CatalogItems"
$bytes = [System.IO.File]::ReadAllBytes($uploadItemPath)
$payload = @{
    "@odata.type" = "#Model.Report";
    "Content" = [System.Convert]::ToBase64String($bytes);
    "ContentType"="";
    "Name" = 'test';
    "Path" = '/SqlSat707';
    } | ConvertTo-Json
Invoke-WebRequest -Uri $catalogItemsUri -Method Post -Body $payload -ContentType "application/json" -UseDefaultCredentials | Out-Null


Write-Host "Download an item..."
$downloadPath = 'C:\SqlSat707\Downloads\test.rdl'
$catalogItemsApi = $ReportPortalUri + "/api/v2.0/CatalogItems(Path='/SqlSat707/test')/Content/$value"
$url = [string]::Format($catalogItemsApi, $item)
$response = Invoke-WebRequest -Uri $url -Method Get -UseDefaultCredentials
[System.IO.File]::WriteAllBytes($downloadPath, $response.Content)


Write-Host "Delete an item..."
$url = $ReportPortalUri + "/api/v2.0/CatalogItems(Path='/SqlSat707/test')"
Invoke-WebRequest -Uri $url -Method Delete -UseDefaultCredentials | Out-Null