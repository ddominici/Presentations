﻿#
# SQL Saturday 707 Pordenone
# 
# List data sources
#
# https://msdn.microsoft.com/en-us/library/reportservice2010.reportingservice2010.createfolder.aspx
#

$folder = "/SqlSat707";

$ssrsServer = "http://localhost/ReportServer";

$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;

$ns = $ssrsMgmtProxy.GetType().Namespace;


$ssrsMgmtProxy.ListChildren($folder, $false) | 
    Where-Object { $_.TypeName -eq "Report" } | ForEach-Object{

    $reportName = $_.Name;
    $reportPath = $_.Path;
    $itemType   = $_.TypeName;
  
    $references = $ssrsMgmtProxy.GetItemDataSources($reportPath);
    $references | Select @{Name="ReportName"; Expression={$reportName}},
        @{Name="ReportPath";Expression={$reportPath}},
        @{Name="ItemTypeName";Expression={$itemType}},
        Name, 
        @{Name="Reference";Expression={$_.Item.Reference}},
        @{Name="ConnectString";Expression={$_.Item.ConnectString}},
        @{Name="CredentialRetrieval";Expression={$_.Item.CredentialRetrieval}},
        @{Name="Extension";Expression={$_.Item.Extension}},
        @{Name="UserName";Expression={$_.Item.UserName}},
        @{Name="WindowsCredentials";Expression={$_.Item.WindowsCredentials}},
        Item

};

$references | ft