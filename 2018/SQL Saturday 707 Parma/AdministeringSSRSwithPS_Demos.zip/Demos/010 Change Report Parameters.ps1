﻿#
# SQL Saturday 707 Pordenone
# 
# Change report parameters
#
# https://msdn.microsoft.com/en-us/library/reportservice2010.reportingservice2010.createfolder.aspx
#

#region "Workaround to handle null properly"

# https://social.msdn.microsoft.com/Forums/en-US/95988820-29b5-4655-80db-ff4ca9a48974/powershell-query-to-ssrs-reportingservice2010-getitemparamters-method?forum=sqlreportingservices

$b = @"
using System;
namespace PsNullString
{
  public class NullString
  {
      public override string ToString() { return null;}
  }
}
"@
add-type $b
$psnull = New-Object PsNullString.NullString

#endregion

$reportPath = "/SqlSat707";

$paramName  = "FontName";
$paramValue = "Calibri";


$ssrsServer = "http://localhost/ReportServer";

$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;

Try {

    $reports = $ssrsMgmtProxy.ListChildren($reportPath,$false) | 
        Where { $_.TypeName -eq "Report" } | ForEach-Object {

            $reportName = $_.Name;
            $reportPath = $_.Path;

            $params = $ssrsMgmtProxy.GetItemParameters(
                $reportPath,
                $psnull ,          # HistoryID
                $false,            # For Rendering
                $null,             # Parameter Values
                $null              # Credentials
            );

            $change = $false;
            for ($i=0;$i -lt $params.Count;$i++) {

                if ($params[$i].Name -eq $paramName) {

                    Write-Host "Changing param '$($paramName)' on report '$($reportPath)' with value '$($paramValue)'";

                    $params[$i].DefaultValues = @($paramValue);
                    $change = $true;
                }
            }
    
            if ($change) {

                $ssrsMgmtProxy.SetItemParameters(
                    $reportPath,
                    $params         # The parameters for item , with changes
                );
            }
    }
}
Catch
{
    Write-Host -ForegroundColor Red $_.Exception.Message;
}
#EOF