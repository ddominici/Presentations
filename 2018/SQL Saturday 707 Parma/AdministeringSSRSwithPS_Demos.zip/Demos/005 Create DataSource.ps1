﻿#
# SQL Saturday 707 Pordenone
# 
# Create datasource
#
# https://msdn.microsoft.com/en-us/library/reportservice2010.reportingservice2010.createfolder.aspx
#

#region "Workaround to handle null properly"

# https://social.msdn.microsoft.com/Forums/en-US/95988820-29b5-4655-80db-ff4ca9a48974/powershell-query-to-ssrs-reportingservice2010-getitemparamters-method?forum=sqlreportingservices

$b = @"
using System;
namespace PsNullString
{
  public class NullString
  {
      public override string ToString() { return null;}
  }
}
"@
add-type $b
$psnull = New-Object PsNullString.NullString

#endregion

$datasourceFolder     = "/SqlSat707";

$datasourceName = "AdventureWorks2014";

$ssrsServer = "http://localhost/reportserver";

$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;

# Get the namespace used for the management proxy
$ns = $ssrsMgmtProxy.GetType().Namespace;
$typeDataSource = $ns + ".DataSourceDefinition";

# Create data source definition object
$dataSourceDefn = New-Object $typeDataSource;

$dataSourceDefn.ConnectString = "Data Source=localhost;Initial Catalog=AdventureWorks2014";
$dataSourceDefn.Extension = "SQL";
$dataSourceDefn.CredentialRetrieval = "Store";
$datasourceDefn.WindowsCredentials = $false
$dataSourceDefn.UserName = "adv2014_reader";
$dataSourceDefn.Password = "P@ssw0rd";
$dataSourceDefn.ImpersonateUser = $false;
$dataSourceDefn.Enabled = $true;
$dataSourceDefn.Prompt = $psnull;

$datasourceDefHash = @{
    'ConnectString' = "Data Source=localhost;Initial Catalog=AdventureWorks2014";; 
    'UserName' = "adv2014_reader"; 
    'Password' = "P@ssw0rd"; 
    'WindowsCredentials' = $false; 
    'Enabled' = $true; 
    'Extension' = 'SQL'; 
    'ImpersonateUser' = $false; 
    'ImpersonateUserSpecified' = $true; 
    'CredentialRetrieval' = 'Store';
}

#convert the hashtable to an array of proxynamespace property items. https://msdn.microsoft.com/en-us/library/reportservice2010.property.aspx
$propertyCollection = $datasourceDefHash.Keys.foreach{ 
    @{ 
        Name = $_; 
        Value = $dataSourceDefHash[$_] 
    } -as "${ns}.property" 
}

try {
    $ssrsMgmtProxy.CreateDataSource($datasourceName, $datasourceFolder, $true, $datasourceDefn, $propertyCollection)
}
catch {
    "Error was $_"
    $line = $_.InvocationInfo.ScriptLineNumber
    "Error was in Line $line"
}
#EOF