﻿#
# SQL Saturday 707 Pordenone
# 
# Upload data source(s)
#
# https://msdn.microsoft.com/en-us/library/reportservice2010.reportingservice2010.createfolder.aspx
#

$parentFolder = "/"
$newFolder    = "MyDataSources";
$fileSource   = "C:\sqlsat707\downloads\";

$ssrsServer = "http://localhost/ReportServer";

$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;

$ns = $ssrsMgmtProxy.GetType().Namespace;

# Create a new folder
$ssrsMgmtProxy.CreateFolder(
    $newFolder,     # Folder to be created
    $parentFolder,  # Folder into which the new folder is created
    $null);         # Properties to set

# And import the data source
$warnings = $null
 
$files = Get-ChildItem $fileSource'*.rds' ;
$files;

foreach($report in $files) {

    $reportName = [System.IO.Path]::GetFileNameWithoutExtension($report.Name)
    $bytes = [System.IO.File]::ReadAllBytes($report.FullName)

    $report.FullName
    Write-Output "Uploading report ""$reportName"" to ""$folder""..."

    $folder = $parentFolder + $newFolder;

    $ssrsMgmtProxy.CreateCatalogItem(
        "Dataset",        # You specify what kind of object you are uploading
        $reportName,      # Name of the report
        $folder,          # Folder 
        $true,            # Overwrite flag
        $bytes,           # Contents of the file
        $null,            # Properties
        [ref]$warnings)   # Warnings

}

#EOF