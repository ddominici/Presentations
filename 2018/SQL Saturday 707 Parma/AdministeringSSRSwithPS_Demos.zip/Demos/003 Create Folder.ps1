﻿#
# SQL Saturday 707 Pordenone
# 
# Create folder using the CreateFolder web service method
#
# https://msdn.microsoft.com/en-us/library/reportservice2010.reportingservice2010.createfolder.aspx
#

$parentFolder = "/";
$newFolder    = "SqlSat707";

$ssrsServer = "http://localhost/ReportServer";

$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;

Try {
    $ssrsMgmtProxy.CreateFolder(
        $newFolder,    # Folder to be created
        $parentFolder, # Folder into which the new folder is created
        $null);        # Properties to set

    Write-Host "Folder created!";
}
Catch
{
    "Error was $_"
    $line = $_.InvocationInfo.ScriptLineNumber
    "Error was in Line $line"
}
#EOF