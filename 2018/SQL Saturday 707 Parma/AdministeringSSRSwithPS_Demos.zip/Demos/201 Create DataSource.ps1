﻿#
# SQL Saturday 707 Pordenone
# 
# Create datasource via ReportingServicesTools
#

Import-Module ReportingServicesTools

New-RsDataSource -RsFolder "/SqlSat707" -Name "ADV2014" -Description "Local Adventure Works 2014 database" -Extension "SQL" -ConnectionString "Data source=localhost;Initial catalog=ADV2014" -CredentialRetrieval Integrated -ReportServerUri http://localhost/Reportserver
 