﻿#
# SQL Saturday 707 Pordenone
# 
# Create folder using the CreateFolder web service method
#
# https://msdn.microsoft.com/en-us/library/reportservice2010.reportingservice2010.createfolder.aspx
#

$folder = "/SqlSat707";
$fileSource = "C:\SQLSat707\Source\Sales Quota By Territory.rdl";
#$fileSource = "C:\SQLSat707\Source\Product List.rdl";

$ssrsServer = "http://localhost/ReportServer";

$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;

Try {
    # This is needed for the ref clause in the method
    $warnings = $null
 
    $report = Get-ChildItem $fileSource;

    $reportName = [System.IO.Path]::GetFileNameWithoutExtension($report.Name)
    $bytes = [System.IO.File]::ReadAllBytes($report.FullName)
 
    Write-Output "Uploading report ""$reportName"" to ""$folder""..."

    $ssrsMgmtProxy.CreateCatalogItem(
        "Report",         # You specify what kind of object you are uploading
        $reportName,      # Name of the report
        $folder,          # Folder 
        $true,            # Overwrite flag
        $bytes,           # Contents of the file
        $null,            # Properties
        [ref]$warnings)   # Warnings
}
Catch
{
    "Error was $_"
    $line = $_.InvocationInfo.ScriptLineNumber
    "Error was in Line $line"
}

#EOF