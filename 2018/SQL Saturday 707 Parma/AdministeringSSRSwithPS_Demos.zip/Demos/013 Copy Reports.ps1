﻿#
# SQL Saturday 707 Pordenone
# 
# Copy reports
#
# https://msdn.microsoft.com/en-us/library/reportservice2010.reportingservice2010.createfolder.aspx
#

$parentFolder = "/";
$sourceFolder = "/SqlSat707";
$targetFolder = "DuplicateFolder"

$ssrsServer = "http://localhost/ReportServer";

$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;

Try {

    # Create the target folder
    Try {
        $ssrsMgmtProxy.CreateFolder($targetFolder, $parentFolder, $null);
    }
    Catch {
    }

    # Get all of the reports and copy
    $warnings = $null;

    $ssrsMgmtProxy.ListChildren($sourceFolder, $false) | 
        Where-Object  {$_.TypeName -eq "Report"} | Foreach-Object {
        
            $reportName = $_.Name;
                
            $bytes = $ssrsMgmtProxy.GetItemDefinition($_.Path);
                
            $ssrsMgmtProxy.CreateCatalogItem(
                "Report",         # You specify what kind of object you are uploading
                $reportName,      # Name of the report
                $parentFolder + $targetFolder,    # Folder 
                $true,            # Overwrite flag
                $bytes,           # Contents of the file
                $null,            # Properties
                [ref]$warnings)   # Warnings

        }
}
Catch
{
    Write-Host -ForegroundColor Red $_.Exception.Message;
}
#EOF