﻿#
# SQL Saturday 707 Pordenone
# 
# Add user or group to a SSRS report via ReportingServicesTools
#

Import-Module ReportingServicesTools

Grant-AccessOnCatalogItem -ReportServerUri http://localhost/reportserver -Identity "DESKTOP-3HOJN25\ReportUser" -RoleName "Browser" -Path "/SqlSat707/Product List"