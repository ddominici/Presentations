﻿$dataSource = "/SqlSat707/AdventureWorks2014";
$targetFile = "C:\SqlSat707\Downloads\AdventureWorks2014.rds"

$ssrsServer = "http://localhost/ReportServer";

$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;

$bytes = $ssrsMgmtProxy.GetItemDefinition($dataSource);

[io.file]::WriteAllBytes($targetFile ,$bytes)

#EOF