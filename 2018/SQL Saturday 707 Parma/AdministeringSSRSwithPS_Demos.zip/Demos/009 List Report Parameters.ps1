﻿#
# SQL Saturday 707 Pordenone
# 
# List report parameters
#
# https://msdn.microsoft.com/en-us/library/reportservice2010.reportingservice2010.createfolder.aspx
#

#region "Workaround to handle null properly"

# https://social.msdn.microsoft.com/Forums/en-US/95988820-29b5-4655-80db-ff4ca9a48974/powershell-query-to-ssrs-reportingservice2010-getitemparamters-method?forum=sqlreportingservices

$b = @"
using System;
namespace PsNullString
{
  public class NullString
  {
      public override string ToString() { return null;}
  }
}
"@
add-type $b
$psnull = New-Object PsNullString.NullString

#endregion

$reportPath = "/SqlSat707/Sales Quota by Territory";

$ssrsServer = "http://localhost/ReportServer";

$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;

Try {

    $reports = $ssrsMgmtProxy.ListChildren("/",$true)

    # Filter by type "Report"
    $reports | Select Name, Path, TypeName | Where { $_.TypeName -eq "Report" } | 
    foreach-object {

        $reportName = $_.Name;
        $reportPath = $_.Path;

        $params = $ssrsMgmtProxy.GetItemParameters(
            $reportPath,
            $psnull ,          # HistoryID
            $false,            # For Rendering
            $null,             # Parameter Values
            $null              # Credentials
        );

        $params | SELECT Name, @{Name="ReportName";Expression={$reportName}},
             ParameterTypeName, 
             Nullable, 
             NullableSpecified, 
             AllowBlank, 
             DefaultValues;

    } | Out-GridView;
}
Catch
{
    Write-Host -ForegroundColor Red $_.Exception.Message;
}
#EOF
