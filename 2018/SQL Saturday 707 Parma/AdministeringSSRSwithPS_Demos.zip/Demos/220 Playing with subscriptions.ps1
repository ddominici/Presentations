﻿#
# SQL Saturday 707 Pordenone
# 
# Playing with subscriptions
#
# http://wragg.io/managing-sql-server-reporting-services-subscriptions-with-powershell/
#

Import-Module ReportingServicesTools

#Get-RsSubscription -ReportServerUri http://localhost/reportserver -Path "/SQLSat707/Product List" | Export-RsSubscriptionXml -Path "C:\SqlSat707\Downloads\Product List Subscription.xml" 

# Import-RsSubscriptionXml "C:\SqlSat707\Source\Product List Subscription.xml"  | Set-RsSubscription -Path '/SqlSat707/Product List'

New-RsSubscription -ReportServerUri http://localhost/Reportserver -path '/SqlSat707/Product List' -Description 'Listino prezzi giornaliero' -Destination 'FileShare' -Schedule (New-RsScheduleXML -Daily 1) -DestinationPath '\\DESKTOP-3HOJN25\Subscriptions\' -Filename 'ListinoGiornaliero' -RenderFormat 'PDF'

# Get-Help New-RsSubscription -Detailed