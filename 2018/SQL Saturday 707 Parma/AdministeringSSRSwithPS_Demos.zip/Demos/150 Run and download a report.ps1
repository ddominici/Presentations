﻿#
# SQL Saturday 707 Pordenone
#
#
# https://msdn.microsoft.com/en-us/library/reportexecution2005.reportexecutionservice.render2.aspx
#

$file         = "C:\SqlSat707\Downloads\Sales Quota By Territory.pdf";
$reportSource = "C:\SqlSat707\Source\Sales Quota By Territory.rdl";

$bytes = [System.IO.File]::ReadAllBytes($reportSource)

$ssrsServer = "http://localhost/reportserver";

$ssrsExecProxy = New-WebServiceProxy $ssrsServer'/ReportExecution2005.asmx?WSDL' `
	-UseDefaultCredential;

# Get the namespace used for the management proxy
$ns = $ssrsExecProxy.GetType().Namespace;
$ParameterValueDT = $ns + ".ParameterValue";

# First load the report definition
[Array] $Warnings = $null;
$ssrsExecProxy.LoadReportDefinition2($bytes,[REF]$Warnings);

# Use to find out available formats:  $ssrsExecProxy.ListRenderingExtensions()
$Format = "PDF";

[string]$Extension = $null;
[string]$MimeType  = $null;
[string]$Encoding  = $null;
[Array] $StreamIds = $null;

Write-Host "Generating report..."

$rpt = $ssrsExecProxy.Render2(
    $Format ,         # string Format,
	"",               # string DeviceInfo,
	"Actual",         # PageCountMode PaginationMode, Actual, Estimate
	[Ref]$Extension,  #out string Extension,
	[Ref]$MimeType,   #out string MimeType,
	[Ref]$Encoding,   #out string Encoding,
	[Ref]$Warnings,   #out Warning[] Warnings,
	[Ref]$StreamIds); #out string[] StreamIds

[System.IO.File]::WriteAllBytes($file, $rpt);

Write-Host "Download complete!"