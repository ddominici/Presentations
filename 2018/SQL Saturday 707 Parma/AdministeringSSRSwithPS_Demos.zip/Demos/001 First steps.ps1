﻿#
# SQL Saturday 707 Pordenone
# 
# Connect to SSRS
#

# SSRS web services Uri
$ssrsServer = "http://localhost/ReportServer";

# Create a proxy using the management web service.
$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;

# Get the namespace used for the management proxy
$mgmtNs = $ssrsMgmtProxy.GetType().Namespace;

$mgmtNs | ft

# Execution Proxy.  The methods exposed by this web service allow you to produce reports.  If you
# want to save a report to a pdf, this is the proxy that you use

$ssrsExecProxy = New-WebServiceProxy $ssrsServer'/ReportExecution2005.asmx?WSDL' `
	-UseDefaultCredential;

# Get the namespace used for the management proxy
$execNs = $ssrsExecProxy.GetType().Namespace;

$execNs | ft