﻿#
# SQL Saturday 707 Pordenone
# 
# List folder and report permissions
#

Import-Module ReportingServicesTools

$startTime = Get-Date

#Declare SSRS URI
$reportServerUri = 'http://localhost/ReportServer/ReportService2010.asmx?wsdl'

#Declare final Security Array
$rsSecurity = @()

#Declare Proxy so we dont need to connect with every command
$proxy = New-RsWebServiceProxy -ReportServerUri $reportServerUri

#List all folders in SSRS
$folders = Get-RsFolderContent -Proxy $proxy -RsFolder '/' -Recurse | Where-Object{$_.TypeName -eq 'Folder'}
 
#Loop through each folder and add its security to the Security Array
foreach($folder in $folders.Path)
{
	# Returns the security on a folder
	$security = Get-RsCatalogItemRole -Proxy $proxy -Path $folder

	#Add to Security Array
	$rsSecurity += $security | SELECT Identity, Path, @{n="Roles";e={$_.Roles.name}}
}

$rsSecurity | Export-csv -Path C:\SqlSat707\SSRS_Folder_Security.csv -NoTypeInformation

$rsSecurity | Out-GridView

$endTime = Get-Date
 
$startTime
$endTime