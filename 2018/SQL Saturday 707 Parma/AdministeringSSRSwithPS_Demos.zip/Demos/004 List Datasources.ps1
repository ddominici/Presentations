﻿#
# SQL Saturday 707 Pordenone
# 
# List datasources
#
# https://msdn.microsoft.com/en-us/library/reportservice2010.reportingservice2010.createfolder.aspx
#

$folder     = "/SqlSat707";

$ssrsServer = "http://localhost/ReportServer";

$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;

$ssrsMgmtProxy.ListChildren($folder, $false) |
    Where-Object { $_.TypeName -eq "DataSource" } | Select Name, Path, TypeName #| Out-GridView;

#EOF