﻿#
# SQL Saturday 707 Pordenone
# 
# Change data source with a shared one
#
# https://msdn.microsoft.com/en-us/library/reportservice2010.reportingservice2010.createfolder.aspx
#

$folder        = "/DuplicateFolder";
$DataSourceURI = "/MyDataSources/AdventureWorks2014";
$referenceName = "AdventureWorks2014";

#region "workaround for managing nulls"

$b = @"
using System;
namespace PsNullString
{
  public class NullString
  {
      public override string ToString() { return null;}
  }
}
"@
add-type $b
$psnull = New-Object PsNullString.NullString

#endregion

$ssrsServer = "http://localhost/ReportServer";

$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;

$ns = $ssrsMgmtProxy.GetType().Namespace;

$DSReferenceDT = $ns + ".DataSourceReference";
$DSDT = $ns + ".DataSource";

$ssrsMgmtProxy.ListChildren($folder,$false) |
    Where-Object { $_.TypeName -eq "Report" } | ForEach-Object {
        $reportName = $_.Name;
        $reportPath = $_.Path;
        $itemType = $_.TypeName;
   
        $references = $ssrsMgmtProxy.GetItemDataSources($reportPath) |
        Where-Object {$_.Name -eq $referenceName};

        ForEach ($ref in $references ){
            $dataSource = New-Object $DSDT
            $dataSource.Name = $ref.Name;
            $dataSource.Item = New-Object $DSReferenceDT;
            $dataSource.Item.Reference = $DataSourceURI # Path to the shared data source.
            $ssrsMgmtProxy.SetItemDataSources($reportPath, $dataSource)
        }
};