﻿#
# SQL Saturday 707 Pordenone
# 
# Get cache options
#
# https://msdn.microsoft.com/en-us/library/reportservice2010.reportingservice2010.createfolder.aspx
# https://msdn.microsoft.com/en-us/library/reportservice2010.timeexpiration.aspx
# https://msdn.microsoft.com/en-us/library/reportservice2010.scheduleexpiration.aspx
#

$reportPath = "/SqlSat707/Product List";

$ssrsServer = "http://localhost/ReportServer";

$ssrsMgmtProxy = New-WebServiceProxy $ssrsServer'/ReportService2010.asmx?WSDL' `
	-UseDefaultCredential;

$expItem = $null;

$isCache = $ssrsMgmtProxy.GetCacheOptions($reportPath, [REF]$expItem);

Write-Host "Is this cached? "$isCache;

if ($isCache) {

    Write-Host "Minutes:  "$expItem.Minutes;
}
