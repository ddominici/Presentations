namespace SantaDeliveryApp.Models;

public class DeliveryInfo
{
    public int Id { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Region { get; set; }
    public double Latitude { get; set; }
    public double Longitude { get; set; }
    public DateTime DeliveryTime { get; set; }
}