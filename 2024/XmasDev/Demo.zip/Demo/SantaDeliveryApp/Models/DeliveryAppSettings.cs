namespace SantaDeliveryApp.Models;

public class DeliveryAppSettings
{
    public string BaseUrl { get; set; }
}