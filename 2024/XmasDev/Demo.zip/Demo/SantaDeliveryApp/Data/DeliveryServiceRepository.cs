using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using SantaDeliveryApp.Models;

namespace SantaDeliveryApp.Data
{
    public class DeliveryServiceRepository
    {
        private readonly string _connectionString;

        public DeliveryServiceRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("AzureSqlDb");
        }

        public async Task<IEnumerable<DeliveryInfo>> GetAllDeliveriesAsync()
        {
            using (IDbConnection db = new SqlConnection(_connectionString))
            {
                string query = "SELECT TOP 10 * FROM Deliveries ORDER BY Id DESC";
                return await db.QueryAsync<DeliveryInfo>(query);
            }
        }
    }
}