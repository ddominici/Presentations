using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using SantaDeliveryApp.Models;

namespace SantaDeliveryApp.Data
{
    public class DeliveryService
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<DeliveryService> _logger;

        public DeliveryService(HttpClient httpClient, IOptions<DeliveryAppSettings> settings, ILogger<DeliveryService> logger)
        {
            _httpClient = httpClient;
            _httpClient.BaseAddress = new Uri(settings.Value.BaseUrl);
            _logger = logger;
        }

        public async Task<bool> RegisterDelivery(DeliveryRequest request)
        {
            try
            {
                _logger.LogInformation("Preparing to send delivery data: {@Request}", request);

                if (request.DeliveryTime == null) request.DeliveryTime = DateTime.Now;
                var json = JsonSerializer.Serialize(request);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync("api/deliveries", content);
                if (response.IsSuccessStatusCode)
                {
                    _logger.LogInformation("Delivery successfully registered: {Response}", response);
                    return response.IsSuccessStatusCode;
                }
                else
                {
                    _logger.LogWarning("Failed to register delivery. Response: {Response}", response);
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while sending delivery data.");
                return false;
            }
        }
    }
}