using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SantaDeliveryApp.Data;
using SantaDeliveryApp.Models;

var builder = WebApplication.CreateBuilder(args);

// Configura il logging
builder.Logging.ClearProviders();
builder.Logging.AddConsole(); // Per vedere i log nella console

// Aggiungi i servizi
builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor();
builder.Services.AddHttpClient<DeliveryService>(client =>
{
    client.BaseAddress = new Uri("https://localhost:5001/");
});
builder.Services.AddScoped<DeliveryServiceRepository>();
builder.Services.Configure<DeliveryAppSettings>(builder.Configuration.GetSection("DeliveryAppSettings"));

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();