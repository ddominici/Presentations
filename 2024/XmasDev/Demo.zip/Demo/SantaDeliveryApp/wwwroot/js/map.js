var map;
var marker;

// Initialize the map
function initMap(latFieldId, lngFieldId) {
    if (typeof L === "undefined") {
        console.error("Leaflet is not loaded. Check the script inclusion.");
        return;
    }
    
    // Center map to Microsoft Rome
    map = L.map('map').setView([41.821307773980976, 12.458822094548681], 13);

    // Add OpenStreetMap tile layer
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    var marker = L.marker([41.821307773980976, 12.458822094548681]).addTo(map);

    // Add click event to map
    map.on('click', function (e) {
        const { lat, lng } = e.latlng;

        // Set marker on the map
        if (marker) {
            marker.setLatLng([lat, lng]);
        } else {
            marker = L.marker([lat, lng]).addTo(map);
        }

        // Fill the latitude and longitude fields
        document.getElementById(latFieldId).value = lat.toFixed(6);
        document.getElementById(lngFieldId).value = lng.toFixed(6);

        // Trigger change event for Blazor
        document.getElementById(latFieldId).dispatchEvent(new Event('change'));
        document.getElementById(lngFieldId).dispatchEvent(new Event('change'));
    });
}
