namespace SantaDeliveryApi.Models;

public class DeliveryApiSettings
{
    public string Broker { get; set; }
    public string Topic { get; set; }
    public string User { get; set; }
    public string Password { get; set; }
}