namespace SantaDeliveryAPI.Models
{
    public class DeliveryRequest
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public DateTime DeliveryTime { get; set; }
    }
}