using Confluent.Kafka;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using SantaDeliveryAPI.Models;
using System.Text.Json;
using SantaDeliveryApi.Models;

namespace SantaDeliveryAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DeliveriesController : ControllerBase
    {
        private readonly IOptions<DeliveryApiSettings> _settings;

        public DeliveriesController(IOptions<DeliveryApiSettings> settings)
        {
            //_configuration = configuration;
            _settings = settings;
        }
        
        /*
        private readonly string _broker = "santa-delivery-eventhub.servicebus.windows.net:9093";
        private readonly string _topic = "deliveries";
        private readonly string _sasUser = "$ConnectionString"; // Nome utente fisso per Event Hub
        private readonly string _sasPassword = "Endpoint=sb://santa-delivery-eventhub.servicebus.windows.net/;SharedAccessKeyName=SantaDeliveryPolicy;SharedAccessKey=T2Hfqz6VRj6PWmc0BQpxyhV6CGVmpHLlp+AEhNBjTp4=;EntityPath=deliveries"; // Connection string primaria
        */
        
        [HttpPost]
        public async Task<IActionResult> RegisterDelivery([FromBody] DeliveryRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            
            var config = new ProducerConfig
            {
                BootstrapServers = _settings.Value.Broker,
                SaslMechanism = SaslMechanism.Plain,
                SecurityProtocol = SecurityProtocol.SaslSsl,
                SaslUsername = _settings.Value.User,
                SaslPassword = _settings.Value.Password
            };

            using var producer = new ProducerBuilder<Null, string>(config).Build();
            var message = JsonSerializer.Serialize(request);
            var _topic = _settings.Value.Topic;

            try
            {
                var result = await producer.ProduceAsync(_topic, new Message<Null, string> { Value = message });
                Console.WriteLine($"Delivery sent to Kafka (partition {result.Partition}, offset {result.Offset})");
                return Ok(new { Message = "Delivery registered and sent to Kafka." });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending message to Kafka: {ex.Message}");
                return StatusCode(500, new { Message = "Failed to send delivery to Kafka." });
            }
        }
    }
}