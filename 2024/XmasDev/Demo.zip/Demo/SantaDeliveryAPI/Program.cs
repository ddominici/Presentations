using FluentValidation;
using FluentValidation.AspNetCore;
using SantaDeliveryApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Aggiungi i servizi necessari
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddFluentValidationAutoValidation();
builder.Services.AddValidatorsFromAssemblyContaining<Program>();
builder.Services.Configure<DeliveryApiSettings>(builder.Configuration.GetSection("DeliveryAppSettings"));

var app = builder.Build();

app.UseSwagger();

if (app.Environment.IsDevelopment())
{
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();